function showDetails(scheme) {
    let url = "";

    if (scheme === 'education-grant') {
        url = "http://localhost/php/education-grant.html";
    } 
    else if (scheme === 'tribal-welfare') {
        url = "http://localhost/php/tribalwelfare.html";
    }
    else if (scheme === 'agriculturalscheme') { // ✅ FIXED TYPO
        url = " http://localhost/php/agricultural.html";
    }
    else if (scheme === 'social-welfare') {
        url = "http://localhost/php/socialwelfare.html";
    }
    else if (scheme === 'sportsandcultural') { // ✅ FIXED TYPO
        url = " http://localhost/php/SportsandCultural.html";
    }
    else if (scheme === 'entrepreneurship') {
        url = "http://localhost/php/Entrepreneurship.html";
    }

    if (url) {
        window.location.href = url; // Redirect to the scheme details page
    } else {
        alert("Invalid scheme selected."); // Show an alert if the scheme is not recognized
    }
}

// Language Selector Event Listener
document.getElementById('language-selector').addEventListener('change', function () {
    let selectedLanguage = this.value;
    
    // Loop through all elements with 'data-en' or 'data-ta' attributes
    document.querySelectorAll('[data-en], [data-ta]').forEach(function (element) {
        let languageText = selectedLanguage === 'en' ? element.getAttribute('data-en') : element.getAttribute('data-ta');
        element.textContent = languageText;
    });
});
