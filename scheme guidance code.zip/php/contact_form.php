<?php
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$mobile = $_POST['mobile'];

$conn = new mysqli('localhost', 'root', '', 'contact_us_db');
if ($conn->connect_error) {
    echo "<script type='text/javascript'>alert('Database connection failed: " . $conn->connect_error . "');</script>";
} else {
    $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message, mobile) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $message, $mobile); // Corrected to "ssss"
    $stmt->execute();
    echo "<script type='text/javascript'>alert('Your Data has been stored successfully!');
    window.location.href = 'scheme.html';</script>";
    $stmt->close();
    $conn->close();
}

$name = isset($_POST['name']) ? $_POST['name'] : null;
$email = isset($_POST['email']) ? $_POST['email'] : null;
$message = isset($_POST['message']) ? $_POST['message'] : null;
$mobile = isset($_POST['mobile']) ? $_POST['mobile'] : null;

if (!$name || !$email || !$message || !$mobile) {
    die("All fields are required.");
}
?>
