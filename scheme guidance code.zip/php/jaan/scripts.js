function showDetails(scheme) {
    let url = "";
    if (scheme === 'health-insurance') {
        url = "https://example.com/health-insurance";
    } else if (scheme === 'education-grant') {
        url = "https://example.com/education-assistance";
    } else if (scheme === 'agricultral-scheme') {
        url = " https://example.com/health-insurance-details";
    }
    else if (scheme === 'social-welfare') {
        url = " https://example.com/health-insurance-details";
    }

    if (url) {
        window.location.href = url; // Redirect to the scheme details page
    } else {
        alert("Invalid scheme selected."); // Show an alert if the scheme is not recognized
    }
}
document.getElementById('language-selector').addEventListener('change', function () {
    let selectedLanguage = this.value;
    
    // Loop through all elements with 'data-en' or 'data-ta' attributes
    document.querySelectorAll('[data-en], [data-ta]').forEach(function (element) {
        let languageText = selectedLanguage === 'en' ? element.getAttribute('data-en') : element.getAttribute('data-ta');
        element.textContent = languageText;
    });
});

function searchScheme() {
    const query = document.getElementById('schemeSearch').value.toLowerCase();
    // For demonstration purposes, we'll use a static array of schemes.
    const schemes = [
        { name: 'Health Scheme', description: 'A scheme for health benefits.' },
        { name: 'Education Scheme', description: 'A scheme for education benefits.' },
        { name: 'Agriculture Scheme', description: 'A scheme for agriculture benefits.' }
    ];

    const resultsContainer = document.getElementById('results');
    resultsContainer.innerHTML = '';

    const filteredSchemes = schemes.filter(scheme => scheme.name.toLowerCase().includes(query));

    if (filteredSchemes.length > 0) {
        filteredSchemes.forEach(scheme => {
            const schemeElement = document.createElement('div');
            schemeElement.innerHTML = `<h3>${scheme.name}</h3><p>${scheme.description}</p>`;
            resultsContainer.appendChild(schemeElement);
        });
    } else {
        resultsContainer.innerHTML = '<p>No schemes found.</p>';
    }
}
